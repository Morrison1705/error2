# Movimiento sincrónico de la pelota
Pelota en movimiento sincrónico
